<?php 

session_start();
session_unset();
session_destroy();




 ?>


 <a href="index.php">homepage</a>