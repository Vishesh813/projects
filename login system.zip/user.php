
<?php 
session_start();

if ($_SESSION['email']) 
{
	 echo "<h2>Welcome ". $_SESSION['email']."</h2>" ;
}

else
	{header('location:login.php');}
        
 ?>

 <a style="align:left;"  href="logout.php">Logout</a>
