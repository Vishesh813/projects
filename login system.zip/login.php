
<?php 
session_start();

 if (isset($_SESSION['email'])) 
   {
     header('location:user.php');
   }

    if(isset($_POST['login']))

     {
       $conn=mysqli_connect('localhost','root','','test_1') or die('database is not selected');    
      $email=mysqli_real_escape_string($conn,$_POST['email']);
      $password=mysqli_real_escape_string($conn,$_POST['password']);
            
        $q3="select * from test where email='$email' AND password='$password'"; 
        $run=mysqli_query($conn,$q3);
        $row=mysqli_fetch_assoc($run);
        $result=mysqli_num_rows($run);

      //  print_r($row) ;

        if($row>0)
        {
               $_SESSION['email']= $row['email'];
               echo  $row['email'];
                    // echo "you are logged in";
         //header('location:user.php');
        }   
         else 
         { echo "Invalid credential"; }    
    }
 ?>


<!DOCTYPE html>
<html>
<head>
	<title>login system</title>

<style type="text/css">
	
</style>
</head>
<body>

<div id="box">
 <center>
  <form action="" method="post">

   	<label>Enter your email id:</label><input type="text" name="email"><br>
    <label>Password:</label><input type="text" name="password"><br>
   	<button type="submit" name="login">LOGIN</button>
     <a style="align:left;"  href="index.php">Register yourself</a>

   </form>
 </center>
   </div>

</body>
</html>