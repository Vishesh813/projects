


<?php 


     //session_start();

     if (isset($_POST['submit']))
      {
     	//echo "button clicked";
     $conn=mysqli_connect('localhost','root','','test_1') or die('database is not selected');

     	$email=mysqli_real_escape_string($conn,$_POST['email']);
     	$password=mysqli_real_escape_string($conn,$_POST['password']);
     	$cpassword=mysqli_real_escape_string($conn,$_POST['cpassword']);
         
         if ($password==$cpassword)
          {
         	
         	$q1="select * from test where email='$email'";
         	$runq1=mysqli_query($conn,$q1) or die("q1 can't run");
         	if (mysqli_num_rows($runq1)>0)
         	 {
         		echo "User already exists";
         	}
         	else

         	{

                 $q2="insert into test (email,password) values ('$email','$password')";
                 $runq2=mysqli_query($conn,$q2) or die("q2 can't run");

                 $_SESSION['email'] = $email;

         	}
         }

         else
         {
         	echo "password and confirm password does'nt matched";
         }
     }



 ?>












<!DOCTYPE html>
<html>
<head>
	<title>login system</title>

<style type="text/css">
	

#box{

position:center;

border:1px red;



}

</style>


</head>
<body>
   


<div id="box">
   <center><form action="" method="post">

   	<label>Enter your email id:</label><input type="text" name="email"><br>
    <label>Password:</label><input type="text" name="password"><br>
   	<label>Confirm password:</label><input type="text" name="cpassword"><br>
   	<button type="submit" name="submit">Register yourself</button>

		   <a href="login.php">log in</a>
		   <a href="forgot.php">Forgot password ?</a>


   </form></center>
   </div>

</body>
</html>