<?php
	if(isset($_POST['name']))	
{
    $msg = 'Name:'.$_POST['name']."\n" 
           'Email:'.$_POST['email']."\n" 
           'Number'.$_POST['number']."\n"
		   'Wish for class:'.$_POST['classfor']."\n"
		   'Subject to learn:'.$_POST['subject']."\n"
		   'Address'.$_POST['address'];
		   

     mail('vishesh.tiwari2427@gmail.com','contact us form',$msg);
	 echo "thank you";
	 

    
}

else
     {	
        echo "error in sending";
      }
?>