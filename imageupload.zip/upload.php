
<html>

<head>
<title>
upload image
</title>
</head>

<body>
<div class = "jumbotron">

<marquee behavior =alternative> Please upload your document here....</marquee>



<form  align="center" action="upload.php" method="post" enctype="multipart/form-data">
     <label>upload your file </label><input type="file" name="files" >
	 <button type="submit" name="submit" value="upload">upload</button>
</form>
</div>
</body>

</html>


<?php

session_start();

if(isset($_POST['submit']))
{
	$imagename = $_FILES['files']['name'];
	$tempimagename = $_FILES['files']['tmp_name'];
	
	$conn = mysqli_connect('localhost','root','','upload') or die(mysql_error());
	
	
	if(!empty($imagename))
	{
		move_uploaded_file($tempimagename,"images/$imagename");		
	    $q = "INSERT INTO `images`( `images`) VALUES ('$imagename')";
	    $run  =mysqli_query($conn,$q);
	     if($run == TRUE)
	    {
	       echo '<script>alert("uploaded successfully") </script>' ; 
	       
	    }
	
	}
	
	else
	{ 
      echo '<script>alert("please choose file first")</script>' ; 
	  exit(0);
	}
	session_destroy();
	
	//header('location: upload.php');
	
	
}
?>
